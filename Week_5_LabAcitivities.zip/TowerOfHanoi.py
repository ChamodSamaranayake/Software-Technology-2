# TowerOfHanoi.py

count = 0 

def main():
    n = eval(input("Enter number of disks: "))  # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print("\nNumber of moves is", count)

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global count
    if n == 1:  # Stopping condition
        count += 1 # add 1 for every move
        print("Move disk", n, "from", fromTower, "to", toTower)
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        count += 1 # add 1 for every move
        print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)

main()  # Call the main function
print()