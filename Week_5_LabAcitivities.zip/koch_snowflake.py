# koch_snowflake.py
from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()  # Create a window
        window.title("Koch snowflake")  # Set a title
        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width = self.width, height = self.height)
        self.canvas.pack()

        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window)  # Create and add a frame to window
        frame1.pack()
        Label(frame1, text = "Enter an order: ").pack(side = LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable = self.order, justify = RIGHT).pack(side = LEFT)
        Button(frame1, text = "Display Snowflake", command = self.display).pack(side = LEFT)
        window.mainloop()  # Create an event loop

    def display(self):
        self.canvas.delete("line")

        # Define the three points of the equilateral triangle
        p1 = [self.width / 2, 80]
        p2 = [80, self.height - 80]
        p3 = [self.width - 80, self.height - 80]

        order = int(self.order.get())

        # Draw Koch curve on each side of the triangle
        self.displaySnowflake(order, p1, p2)
        self.displaySnowflake(order, p2, p3)
        self.displaySnowflake(order, p3, p1)

    def displaySnowflake(self, order, p1, p2):
        if order == 0:  # Draw a straight line
            self.drawLine(p1, p2)
        else:

            p3 = [(2 * p1[0] + p2[0]) / 3, (2 * p1[1] + p2[1]) / 3]
            p4 = [(p1[0] + 2 * p2[0]) / 3, (p1[1] + 2 * p2[1]) / 3]

            angle = math.atan2(p4[1] - p3[1], p4[0] - p3[0]) + math.pi / 3
            length = math.sqrt((p4[0] - p3[0]) ** 2 + (p4[1] - p3[1]) ** 2)
            p5 = [p3[0] + length * math.cos(angle),
                  p3[1] + length * math.sin(angle)]

            # Recursively draw the 4 segments
            self.displaySnowflake(order - 1, p1, p3)
            self.displaySnowflake(order - 1, p3, p5)
            self.displaySnowflake(order - 1, p5, p4)
            self.displaySnowflake(order - 1, p4, p2)

    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags = "line")

KochSnowflake()  # Create GUI