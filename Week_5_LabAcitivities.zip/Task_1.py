import random
import timeit


# RECURSION
# At its core, recursion involves solving a problem 
# by breaking it down into smaller, more manageable instances of the same problem. 

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case


# Sum of Natural Numbers (Iterative loop)
def sum_iterative(n): 
    total = 0 
    for i in range(1, n + 1): 
        total += i
    return total

# Example usage:
result = sum_of_natural_numbers(5)  # Calculates 1 + 2 + 3 + 4 + 5
result_2 = sum_iterative(5)
print(f"The sum of the first 5 natural numbers is {result}")
print(f"The sum of the first 5 natural numbers (through iteration) is {result_2}")

print()

# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case
    

# Fibonacci Sequence (Iterative)
def fibonacci_iterative(n):
    if n <= 0:
        return 0
    if n == 1:
        return 1
    previous = 0
    current = 1
    for _ in range(2, n + 1):   # Build up step by step
        previous, current = current, previous + current
    return current

# Example usage:
result = fibonacci(7)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
result_2 = fibonacci_iterative(7)
print(f"The 7th Fibonacci number is {result}")
print(f"The 7th Fibonacci number (through iteration) is {result_2}")


print()
# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!
    

# Factorial (Iterative)
def factorial_iterative(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

# Example usage:
num = 5
result = factorial(num)
result_2 = factorial_iterative(num)
print(f"The factorial of {num} is {result}")
print(f"The factorial of {num} (through iteration) is {result_2}")


print()

# COMPARISON
print("COMPARISON: Recursive vs Iterative")

print()
# Sum
print("Sum of Natural Numbers")
for n in [5, 100, 500]:
    r = timeit.timeit(lambda: sum_of_natural_numbers(n), number=1000)
    i = timeit.timeit(lambda: sum_iterative(n), number=1000)
    print(f"Number = {n}: Recursive = {r:.6f}s  Iterative = {i:.6f}s") # s = seconds

print()
# Fibonacci
print("Fibonacci")
for n in [5, 10, 20, 30]:
    r = timeit.timeit(lambda: fibonacci(n), number=100)
    i = timeit.timeit(lambda: fibonacci_iterative(n), number=100)
    print(f"Number = {n}: Recursive = {r:.6f}s  Iterative = {i:.6f}s") # s = seconds

print()
# Factorial
print("Factorial")
for n in [5, 100, 500]:
    r = timeit.timeit(lambda: factorial(n), number=1000)
    i = timeit.timeit(lambda: factorial_iterative(n), number=1000)
    print(f"Number = {n}: Recursive = {r:.6f}s  Iterative = {i:.6f}s") # s = seconds