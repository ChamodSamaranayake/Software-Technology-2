import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 10
CANVAS_WIDTH = 900
CANVAS_HEIGHT = 200

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Enqueue Value:").grid(row=0, column=0)
        self.enqueue_entry = tk.Entry(control_frame, width=10)
        self.enqueue_entry.grid(row=0, column=1)

        tk.Button(control_frame, text="Enqueue", command=self.enqueue_value).grid(row=0, column=2, padx=5)
        tk.Button(control_frame, text="Dequeue", command=self.dequeue_value).grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT, fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2, text=str(data), font=("Arial", 16))

    def draw_queue(self):
        self.canvas.delete("all")
        y = (CANVAS_HEIGHT - NODE_HEIGHT) // 2
        display = list(reversed(self.queue))
        x = 20
        for val in display:
            self.draw_node(x, y, val)
            x += NODE_WIDTH + HORIZONTAL_GAP
        if self.queue:
            rear_x  = 20
            front_x = 20 + (len(self.queue) - 1) * (NODE_WIDTH + HORIZONTAL_GAP)
            self.canvas.create_text(rear_x  + NODE_WIDTH / 2, y + NODE_HEIGHT + 20, text="Rear",  font=("Arial", 12), fill="red")
            self.canvas.create_text(front_x + NODE_WIDTH / 2, y + NODE_HEIGHT + 20,text="Front", font=("Arial", 12), fill="red")

    def enqueue_value(self):
        try:
            val = int(self.enqueue_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to enqueue.")
            return
        self.queue.append(val)
        self.enqueue_entry.delete(0, tk.END)
        self.status_label.config(text=f"Enqueued {val} onto queue")
        self.draw_queue()

    def dequeue_value(self):
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return
        val = self.queue.pop(0)
        self.status_label.config(text=f"Dequeued {val} from queue")
        self.draw_queue()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
    root.mainloop()