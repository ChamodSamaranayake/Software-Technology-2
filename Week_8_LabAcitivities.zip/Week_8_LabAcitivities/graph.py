#===graph.py===
class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                edges = []
                for neighbour in self.graph[vertex]:
                    weight = self.weights.get((vertex, neighbour), 0)
                    edges.append(f"{neighbour}(w={weight})")
                print(f"{vertex}: {edges}")
            else:
                print(f"{vertex}: {self.graph[vertex]}")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted:
                self.weights.pop((vertex1, vertex2), None)
            if not self.directed:
                self.graph[vertex2].remove(vertex1)
                if self.weighted:
                    self.weights.pop((vertex2, vertex1), None)
        else:
            print("Edge not found.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]
            for v in self.graph:     # Remove all edges pointing to this vertex from other vertices
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    if self.weighted:
                        self.weights.pop((v, vertex), None)
                        self.weights.pop((vertex, v), None)
        else:
            print("Vertex not found.")

    def bfs(self, start):
        visited = []
        queue = [start]
        seen = set([start])

        while queue:
            vertex = queue.pop(0)
            visited.append(vertex)

            for neighbour in self.graph[vertex]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)

        return visited
    
    def dfs(self, start):
        visited = []
        stack = [start]
        seen = set([start])

        while stack:
            vertex = stack.pop()
            visited.append(vertex)

            for neighbour in reversed(self.graph[vertex]):
                if neighbour not in seen:
                    seen.add(neighbour)
                    stack.append(neighbour)

        return visited
    
    def has_undirected_cycle(self):
        visited = set()

        def dfs(vertex, parent):
            visited.add(vertex)
            for neighbour in self.graph[vertex]:
                if neighbour not in visited:
                    if dfs(neighbour, vertex):
                        return True
                elif neighbour != parent:
                    return True
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex, None):
                    return True
        return False
