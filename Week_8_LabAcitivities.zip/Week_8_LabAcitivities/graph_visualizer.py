# === graph_visualizer.py ===
from graph import Graph
import tkinter as tk
import math

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.graph = graph
        self.canvas = tk.Canvas(self, width=400, height=400, bg='white')
        self.canvas.pack()
        self.vertex_positions = {}
        self.draw_graph()

        btn_frame = tk.Frame(self)
        btn_frame.pack()
        tk.Button(btn_frame, text="Add Vertex", command=self.add_vertex).grid(row=0, column=0, padx=5, pady=5)
        tk.Button(btn_frame, text="Remove Vertex", command=self.remove_vertex).grid(row=0, column=1, padx=5, pady=5)
        tk.Button(btn_frame, text="Add Edge", command=self.add_edge).grid(row=0, column=2, padx=5, pady=5)
        tk.Button(btn_frame, text="Remove Edge", command=self.remove_edge).grid(row=0, column=3, padx=5, pady=5)
        tk.Button(btn_frame, text="BFS", command=self.run_bfs).grid(row=1, column=0, padx=5, pady=5)
        tk.Button(btn_frame, text="DFS", command=self.run_dfs).grid(row=1, column=1, padx=5, pady=5)

    def draw_graph(self, highlight=[]):
        self.canvas.delete("all")
        radius = 20
        spacing = 100
        # Arrange vertices in a circle
        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 200, 200
        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)
            color = 'yellow' if v in highlight else 'lightblue'
            self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=color)
            self.canvas.create_text(x, y, text=v)

        # Draw edges
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]
                self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST if self.graph.directed else None)
                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')
                    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")

    def add_vertex(self):
        popup = tk.Toplevel(self)
        popup.title("Add Vertex")
        popup.minsize(400, 100)
        tk.Label(popup, text="Vertex name:").pack()
        entry = tk.Entry(popup)
        entry.pack()
        def confirm():
            self.graph.add_vertex(entry.get().strip().upper())
            self.draw_graph()
            popup.destroy()
        tk.Button(popup, text="Add", command=confirm).pack()

    def remove_vertex(self):
        popup = tk.Toplevel(self)
        popup.title("Remove Vertex")
        popup.minsize(400, 100)
        tk.Label(popup, text="Vertex name:").pack()
        entry = tk.Entry(popup)
        entry.pack()
        def confirm():
            self.graph.remove_vertex(entry.get().strip().upper())
            self.draw_graph()
            popup.destroy()
        tk.Button(popup, text="Remove", command=confirm).pack()

    def add_edge(self):
        popup = tk.Toplevel(self)
        popup.title("Add Edge")
        popup.minsize(400, 100)
        tk.Label(popup, text="From:").pack()
        entry1 = tk.Entry(popup)
        entry1.pack()
        tk.Label(popup, text="To:").pack()
        entry2 = tk.Entry(popup)
        entry2.pack()
        tk.Label(popup, text="Weight (optional):").pack()
        entry3 = tk.Entry(popup)
        entry3.pack()
        def confirm():
            w = int(entry3.get()) if entry3.get() else 0
            self.graph.add_edge(entry1.get().strip().upper(), entry2.get().strip().upper(), w)
            self.draw_graph()
            popup.destroy()
        tk.Button(popup, text="Add", command=confirm).pack()

    def remove_edge(self):
        popup = tk.Toplevel(self)
        popup.title("Remove Edge")
        popup.minsize(400, 100)
        tk.Label(popup, text="From:").pack()
        entry1 = tk.Entry(popup)
        entry1.pack()
        tk.Label(popup, text="To:").pack()
        entry2 = tk.Entry(popup)
        entry2.pack()
        def confirm():
            self.graph.remove_edge(entry1.get().strip().upper(), entry2.get().strip().upper())
            self.draw_graph()
            popup.destroy()
        tk.Button(popup, text="Remove", command=confirm).pack()

    def run_bfs(self):
        visited = self.graph.bfs('A')
        for i, v in enumerate(visited):
            self.after(i * 800, lambda v=v, visited=visited[:visited.index(v)+1]: self.draw_graph(visited))

    def run_dfs(self):
        visited = self.graph.dfs('A')
        for i, v in enumerate(visited):
            self.after(i * 800, lambda v=v, visited=visited[:visited.index(v)+1]: self.draw_graph(visited))


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'A', 30)

    app = GraphVisualizer(g)
    app.mainloop()
