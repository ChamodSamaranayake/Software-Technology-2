import time
import random
import string
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt

# ===== BST Node and BST Class =====

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

# AVL Node and AVL Tree Class

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)
        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

# Red-Black Tree

RED = True
BLACK = False

class RBNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.parent = None
        self.color = RED

class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, None)
        self.NIL.color = BLACK
        self.root = self.NIL

    def insert(self, name, phone):
        node = RBNode(name, phone)
        node.left = self.NIL
        node.right = self.NIL
        node.color = RED
        parent = None
        current = self.root
        while current != self.NIL:
            parent = current
            if node.name < current.name:
                current = current.left
            elif node.name > current.name:
                current = current.right
            else:
                current.phone = phone
                return
        node.parent = parent
        if parent is None:
            self.root = node
        elif node.name < parent.name:
            parent.left = node
        else:
            parent.right = node
        if node.parent is None:
            node.color = BLACK
            return
        if node.parent.parent is None:
            return
        self._fix_insert(node)

    def _fix_insert(self, node):
        while node.parent and node.parent.color == RED:
            if node.parent == node.parent.parent.left:
                uncle = node.parent.parent.right
                if uncle.color == RED:
                    node.parent.color = BLACK
                    uncle.color = BLACK
                    node.parent.parent.color = RED
                    node = node.parent.parent
                else:
                    if node == node.parent.right:
                        node = node.parent
                        self._left_rotate(node)
                    node.parent.color = BLACK
                    node.parent.parent.color = RED
                    self._right_rotate(node.parent.parent)
            else:
                uncle = node.parent.parent.left
                if uncle.color == RED:
                    node.parent.color = BLACK
                    uncle.color = BLACK
                    node.parent.parent.color = RED
                    node = node.parent.parent
                else:
                    if node == node.parent.left:
                        node = node.parent
                        self._right_rotate(node)
                    node.parent.color = BLACK
                    node.parent.parent.color = RED
                    self._left_rotate(node.parent.parent)
            if node == self.root:
                break
        self.root.color = BLACK

    def _left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def _right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def search(self, name):
        current = self.root
        while current != self.NIL and current.name != name:
            if name < current.name:
                current = current.left
            else:
                current = current.right
        return current if current != self.NIL else None

    def _minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def _transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def delete(self, name):
        node = self.search(name)
        if node is None:
            return
        self._delete_node(node)

    def _delete_node(self, z):
        y = z
        y_original_color = y.color
        if z.left == self.NIL:
            x = z.right
            self._transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self._transplant(z, z.left)
        else:
            y = self._minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self._transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self._transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color
        if y_original_color == BLACK:
            self._fix_delete(x)

    def _fix_delete(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                w = x.parent.right
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self._left_rotate(x.parent)
                    w = x.parent.right
                if w.left.color == BLACK and w.right.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.right.color == BLACK:
                        w.left.color = BLACK
                        w.color = RED
                        self._right_rotate(w)
                        w = x.parent.right
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.right.color = BLACK
                    self._left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self._right_rotate(x.parent)
                    w = x.parent.left
                if w.right.color == BLACK and w.left.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.left.color == BLACK:
                        w.right.color = BLACK
                        w.color = RED
                        self._left_rotate(w)
                        w = x.parent.left
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.left.color = BLACK
                    self._right_rotate(x.parent)
                    x = self.root
        x.color = BLACK

    def inorder(self, node, result=None):
        if result is None:
            result = []
        if node != self.NIL and node is not None:
            self.inorder(node.left, result)
            result.append((node.name, node.phone))
            self.inorder(node.right, result)
        return result


# RBT GUI App

class RBTApp:
    def __init__(self, master):
        self.rbt = RedBlackTree()
        self.master = master
        master.title("Red-Black Tree Contact Directory")

        # Input frame
        frame = tk.Frame(master)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0, padx=5)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1, padx=5)

        tk.Label(frame, text="Phone:").grid(row=1, column=0, padx=5)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1, padx=5)

        # Buttons
        btn_frame = tk.Frame(master)
        btn_frame.pack(pady=5)

        tk.Button(btn_frame, text="Insert Contact",
                  command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Search Contact",
                  command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Delete Contact",
                  command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(btn_frame, text="Show All Contacts",
                  command=self.show_all).grid(row=0, column=3, padx=5)
        tk.Button(btn_frame, text="Run Benchmark",
                  command=self.run_benchmark).grid(row=0, column=4, padx=5)

        # Output text box
        self.output_text = tk.Text(master, height=10, width=70)
        self.output_text.pack(pady=10)

        # Canvas for tree visualization
        self.canvas = tk.Canvas(master, width=900, height=400, bg="white")
        self.canvas.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return
        self.rbt.insert(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to search.")
            return
        node = self.rbt.search(name)
        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(tk.END,
                f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to delete.")
            return
        self.rbt.delete(name)
        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.rbt.inorder(self.rbt.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for n, p in contacts:
                self.output_text.insert(tk.END, f"Name: {n}, Phone: {p}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.rbt.root == self.rbt.NIL or self.rbt.root is None:
            return
        width = self.canvas.winfo_width()
        self._draw_node(self.rbt.root, width // 2, 30, width // 4)

    def _draw_node(self, node, x, y, x_offset):
        if node == self.rbt.NIL or node is None:
            return
        radius = 22

        if node.left != self.rbt.NIL:
            x_left = x - x_offset
            y_left = y + 70
            self.canvas.create_line(x, y + radius, x_left, y_left - radius, width=2)
            self._draw_node(node.left, x_left, y_left, x_offset // 2)

        if node.right != self.rbt.NIL:
            x_right = x + x_offset
            y_right = y + 70
            self.canvas.create_line(x, y + radius, x_right, y_right - radius, width=2)
            self._draw_node(node.right, x_right, y_right, x_offset // 2)

        fill_color = "red" if node.color == RED else "black"
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                fill=fill_color, outline="gray")
        display_name = node.name if len(node.name) <= 8 else node.name[:8] + "..."
        self.canvas.create_text(x, y, text=display_name,
                                fill="white", font=("Arial", 9, "bold"))

    def run_benchmark(self):
        N = 1000
        names = [''.join(random.choices(string.ascii_lowercase, k=7)) for _ in range(N)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(N)]

        # BST
        bst = BST()
        start = time.time()
        for i in range(N):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_insert = time.time() - start
        start = time.time()
        for name in names[:N//2]:
            bst.search(bst.root, name)
        bst_search = time.time() - start
        start = time.time()
        for name in names[:100]:
            bst.root = bst.delete(bst.root, name)
        bst_delete = time.time() - start

        # AVL
        avl = AVLTree()
        start = time.time()
        for i in range(N):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_insert = time.time() - start
        start = time.time()
        for name in names[:N//2]:
            avl.search(avl.root, name)
        avl_search = time.time() - start
        start = time.time()
        for name in names[:100]:
            avl.root = avl.delete(avl.root, name)
        avl_delete = time.time() - start

        # RBT
        rbt = RedBlackTree()
        start = time.time()
        for i in range(N):
            rbt.insert(names[i], phones[i])
        rbt_insert = time.time() - start
        start = time.time()
        for name in names[:N//2]:
            rbt.search(name)
        rbt_search = time.time() - start
        start = time.time()
        for name in names[:100]:
            rbt.delete(name)
        rbt_delete = time.time() - start

        result = (
            f"Benchmark Results (N={N}):\n"
            f"{'Operation':<12} {'BST':>12} {'AVL':>12} {'RBT':>12}\n"
            f"{'-'*50}\n"
            f"{'Insertion':<12} {bst_insert:>12.6f}s {avl_insert:>12.6f}s {rbt_insert:>12.6f}s\n"
            f"{'Search':<12} {bst_search:>12.6f}s {avl_search:>12.6f}s {rbt_search:>12.6f}s\n"
            f"{'Deletion':<12} {bst_delete:>12.6f}s {avl_delete:>12.6f}s {rbt_delete:>12.6f}s\n"
        )
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, result)

# Matplotlib Benchmark

def run_benchmark_for_sizes(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rbt_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        # BST
        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)
        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)
        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        # AVL
        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)
        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)
        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

        # RBT
        rbt = RedBlackTree()
        start = time.time()
        for i in range(n):
            rbt.insert(names[i], phones[i])
        rbt_times['insert'].append(time.time() - start)
        start = time.time()
        for name in search_names:
            rbt.search(name)
        rbt_times['search'].append(time.time() - start)
        start = time.time()
        for name in delete_names:
            rbt.delete(name)
        rbt_times['delete'].append(time.time() - start)

    plt.figure(figsize=(12, 8))

    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times['insert'], label='BST Insert')
    plt.plot(sizes, avl_times['insert'], label='AVL Insert')
    plt.plot(sizes, rbt_times['insert'], label='RBT Insert')
    plt.ylabel('Time (seconds)')
    plt.title('Insertion Time vs Input Size')
    plt.legend()

    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times['search'], label='BST Search')
    plt.plot(sizes, avl_times['search'], label='AVL Search')
    plt.plot(sizes, rbt_times['search'], label='RBT Search')
    plt.ylabel('Time (seconds)')
    plt.title('Search Time vs Input Size')
    plt.legend()

    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times['delete'], label='BST Delete')
    plt.plot(sizes, avl_times['delete'], label='AVL Delete')
    plt.plot(sizes, rbt_times['delete'], label='RBT Delete')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Time (seconds)')
    plt.title('Deletion Time vs Input Size')
    plt.legend()

    plt.tight_layout()
    plt.show()


# Run the app

if __name__ == "__main__":
    # RBT Contact Directory GUI
    rbt_window = tk.Tk()
    rbt_app = RBTApp(rbt_window)
    rbt_window.mainloop()

    # Matplotlib graphs
    sizes_to_test = [100, 200, 400, 800, 1600, 2500, 5000, 10000]
    run_benchmark_for_sizes(sizes_to_test)