# Automated Unit Tests & Benchmarking
# Extended  : Queue, LinkedList, BST, Sorting, Graph, Heap, DP

import sys, os, unittest, time, random, heapq
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from modules.stack import Stack

# Reimplement pure logic classes
class Queue:
    MAX = 10000
    def __init__(self): self.data=[]
    def enqueue(self,v):
        if len(self.data)>=self.MAX: raise OverflowError
        self.data.append(v)
    def dequeue(self):
        if not self.data: raise IndexError
        return self.data.pop(0)
    def front(self): return self.data[0] if self.data else None
    def size(self):  return len(self.data)
    def is_empty(self): return not self.data

class LLNode:
    def __init__(self,v): self.val=v; self.next=None
class LinkedList:
    def __init__(self): self.head=None
    def append(self,v):
        n=LLNode(v)
        if not self.head: self.head=n; return
        c=self.head
        while c.next: c=c.next
        c.next=n
    def insert_at(self,v,pos):
        n=LLNode(v)
        if pos==0: n.next=self.head; self.head=n; return
        c=self.head; i=0
        while c and i<pos-1: c=c.next; i+=1
        if c: n.next=c.next; c.next=n
    def delete(self,v):
        c=self.head; p=None
        while c:
            if c.val==v:
                if p: p.next=c.next
                else: self.head=c.next
                return True
            p=c; c=c.next
        return False
    def reverse(self):
        p=None; c=self.head
        while c: n=c.next; c.next=p; p=c; c=n
        self.head=p
    def to_list(self):
        r=[]; c=self.head
        while c: r.append(c.val); c=c.next
        return r

class BSTNode:
    def __init__(self,v): self.value=v; self.left=self.right=None
class BST:
    def __init__(self): self.root=None
    def insert(self,v): self.root=self._ins(self.root,v)
    def _ins(self,n,v):
        if not n: return BSTNode(v)
        if v<n.value: n.left=self._ins(n.left,v)
        elif v>n.value: n.right=self._ins(n.right,v)
        return n
    def inorder(self):   r=[]; self._in(self.root,r);  return r
    def preorder(self):  r=[]; self._pre(self.root,r); return r
    def postorder(self): r=[]; self._po(self.root,r);  return r
    def _in(self,n,r):
        if n: self._in(n.left,r);  r.append(n.value); self._in(n.right,r)
    def _pre(self,n,r):
        if n: r.append(n.value); self._pre(n.left,r); self._pre(n.right,r)
    def _po(self,n,r):
        if n: self._po(n.left,r);  self._po(n.right,r);  r.append(n.value)

class MinHeap:
    def __init__(self): self.h=[]
    def insert(self,v): heapq.heappush(self.h,v)
    def extract_min(self): return heapq.heappop(self.h) if self.h else None
    def peek(self): return self.h[0] if self.h else None
    def is_valid(self):
        n=len(self.h)
        for i in range(1,n):
            if self.h[(i-1)//2]>self.h[i]: return False
        return True

def bubble_sort(a):
    a=a[:]; n=len(a)
    for i in range(n):
        for j in range(n-1-i):
            if a[j]>a[j+1]: a[j],a[j+1]=a[j+1],a[j]
    return a

def selection_sort(a):
    a=a[:]; n=len(a)
    for i in range(n):
        m=i
        for j in range(i+1,n):
            if a[j]<a[m]: m=j
        a[i],a[m]=a[m],a[i]
    return a

def merge_sort(a):
    if len(a)<=1: return a[:]
    m=len(a)//2
    return _merge(merge_sort(a[:m]),merge_sort(a[m:]))
def _merge(l,r):
    res=[]; i=j=0
    while i<len(l) and j<len(r):
        if l[i]<=r[j]: res.append(l[i]); i+=1
        else: res.append(r[j]); j+=1
    return res+l[i:]+r[j:]

def insertion_sort(a):
    a=a[:]
    for i in range(1,len(a)):
        k=a[i]; j=i-1
        while j>=0 and k<a[j]: a[j+1]=a[j]; j-=1
        a[j+1]=k
    return a

from collections import deque
def bfs(graph,start):
    vis=[start]; q=deque([start])
    while q:
        n=q.popleft()
        for nb in sorted(graph.get(n,[])):
            if nb not in vis: vis.append(nb); q.append(nb)
    return vis

def dfs(graph,start,vis=None):
    if vis is None: vis=[]
    vis.append(start)
    for nb in sorted(graph.get(start,[])):
        if nb not in vis: dfs(graph,nb,vis)
    return vis

def unique_paths(rows,cols,obs=None):
    if obs is None: obs=set()
    dp=[[0]*cols for _ in range(rows)]
    for c in range(cols):
        if (0,c) in obs: break
        dp[0][c]=1
    for r in range(rows):
        if (r,0) in obs: break
        dp[r][0]=1
    for r in range(1,rows):
        for c in range(1,cols):
            if (r,c) not in obs:
                dp[r][c]=dp[r-1][c]+dp[r][c-1]
    return dp[rows-1][cols-1]

# linear search
def linear_search(numbers, target):
    for i,n in enumerate(numbers):
        if n==target: return i
    return -1


#  TEST CLASSES

class TestStack(unittest.TestCase):

    def test_push_pop(self):
        """task_1_4: push/pop 1000 items in LIFO order."""
        s=Stack(max_size=2000)
        for i in range(1000): s.push(i)
        self.assertEqual(s.size(), 1000)
        for i in reversed(range(1000)):
            v=s.pop(); self.assertEqual(v,i)
        self.assertTrue(s.is_empty())

    def test_peek_and_exceptions(self):
        """task_1_4: peek and IndexError on empty stack."""
        s=Stack()
        with self.assertRaises(IndexError): s.pop()
        with self.assertRaises(IndexError): s.peek()
        s.push(42)
        self.assertEqual(s.peek(), 42)
        self.assertEqual(s.size(), 1)

    def test_overflow(self):
        s=Stack(max_size=3)
        for i in range(3): s.push(i)
        with self.assertRaises(OverflowError): s.push(99)

    def test_benchmark(self):
        """task_1_4: push/pop n=10**5 items and measure time."""
        s=Stack(max_size=200000)
        n=10**5
        start=time.time()
        for i in range(n): s.push(i)
        for i in range(n): s.pop()
        elapsed=time.time()-start
        print(f"\n  Benchmark push/pop {n} items: {elapsed:.4f}s")
        self.assertLess(elapsed, 5.0)


class TestQueue(unittest.TestCase):
    """challenge task_1_4 – queue testing."""

    def test_fifo(self):
        q=Queue()
        for v in [1,2,3,4]: q.enqueue(v)
        self.assertEqual(q.dequeue(),1)
        self.assertEqual(q.dequeue(),2)
        self.assertEqual(q.size(),2)
        self.assertEqual(q.front(),3)

    def test_empty_raises(self):
        q=Queue()
        with self.assertRaises(IndexError): q.dequeue()

    def test_overflow_raises(self):
        q=Queue()
        for i in range(Queue.MAX): q.enqueue(i)
        with self.assertRaises(OverflowError): q.enqueue(99)

    def test_benchmark(self):
        q=Queue()
        n=500
        start=time.time()
        for i in range(n): q.enqueue(i)
        for i in range(n): q.dequeue()
        elapsed=time.time()-start
        print(f"\n  Benchmark enqueue/dequeue {n}: {elapsed:.4f}s")
        self.assertLess(elapsed, 2.0)


class TestLinkedList(unittest.TestCase):

    def test_append_and_traverse(self):
        ll=LinkedList()
        for v in [1,2,3]: ll.append(v)
        self.assertEqual(ll.to_list(),[1,2,3])

    def test_insert_at_position(self):
        """challenge 2.1."""
        ll=LinkedList()
        for v in [1,3,4]: ll.append(v)
        ll.insert_at(2,1)
        self.assertEqual(ll.to_list(),[1,2,3,4])

    def test_delete(self):
        ll=LinkedList()
        for v in [5,10,15]: ll.append(v)
        self.assertTrue(ll.delete(10))
        self.assertEqual(ll.to_list(),[5,15])
        self.assertFalse(ll.delete(99))

    def test_reverse(self):
        """challenge 2.1."""
        ll=LinkedList()
        for v in [1,2,3,4,5]: ll.append(v)
        ll.reverse()
        self.assertEqual(ll.to_list(),[5,4,3,2,1])


class TestBST(unittest.TestCase):

    def test_inorder(self):
        bst=BST()
        for v in [50,30,70,20,40]: bst.insert(v)
        self.assertEqual(bst.inorder(),[20,30,40,50,70])

    def test_preorder(self):
        """challenge 2.2."""
        bst=BST()
        for v in [50,30,70]: bst.insert(v)
        self.assertEqual(bst.preorder(),[50,30,70])

    def test_postorder(self):
        """challenge 2.2."""
        bst=BST()
        for v in [50,30,70]: bst.insert(v)
        self.assertEqual(bst.postorder(),[30,70,50])

    def test_bst_property(self):
        bst=BST(); vals=[15,5,20,3,8,18,25]
        for v in vals: bst.insert(v)
        self.assertEqual(bst.inorder(), sorted(vals))


class TestSorting(unittest.TestCase):
    A=[5,3,8,1,2]; E=[1,2,3,5,8]

    def test_bubble(self):  self.assertEqual(bubble_sort(self.A),    self.E)
    def test_selection(self): self.assertEqual(selection_sort(self.A),self.E)
    def test_merge(self):   self.assertEqual(merge_sort(self.A),     self.E)
    def test_insertion(self):self.assertEqual(insertion_sort(self.A),self.E)
    def test_empty(self):   self.assertEqual(bubble_sort([]),[])
    def test_single(self):  self.assertEqual(merge_sort([7]),[7])
    def test_duplicates(self):
        a=[3,1,4,1,5,9,2,6]
        for fn in [bubble_sort,selection_sort,merge_sort,insertion_sort]:
            self.assertEqual(fn(a),sorted(a))


class TestGraphTraversal(unittest.TestCase):
    G={'A':['B','C'],'B':['A','D'],'C':['A'],'D':['B']}

    def test_bfs_order(self):
        r=bfs(self.G,'A')
        self.assertEqual(r[0],'A')
        self.assertEqual(set(r),set(self.G))

    def test_dfs_visits_all(self):
        r=dfs(self.G,'A')
        self.assertEqual(set(r),set(self.G))

    def test_bfs_single(self):
        self.assertEqual(bfs({'X':[]},'X'),['X'])


class TestMinHeap(unittest.TestCase):

    def test_min_property(self):
        mh=MinHeap()
        for v in [10,5,20,1,8]: mh.insert(v)
        self.assertTrue(mh.is_valid())
        self.assertEqual(mh.extract_min(),1)
        self.assertEqual(mh.extract_min(),5)

    def test_sort_via_heap(self):
        mh=MinHeap(); vals=[7,3,11,1,4]
        for v in vals: mh.insert(v)
        result=[mh.extract_min() for _ in range(len(vals))]
        self.assertEqual(result,sorted(vals))


class TestDPUniquePaths(unittest.TestCase):

    def test_3x3(self):     self.assertEqual(unique_paths(3,3),6)
    def test_obstacle(self):self.assertEqual(unique_paths(3,3,{(1,1)}),2)
    def test_1x5(self):     self.assertEqual(unique_paths(1,5),1)
    def test_5x1(self):     self.assertEqual(unique_paths(5,1),1)


class TestLinearSearch(unittest.TestCase):

    def test_found(self):
        self.assertEqual(linear_search([5,3,9,1,7],7),4)
    def test_not_found(self):
        self.assertEqual(linear_search([5,3,9,1,7],99),-1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
