# DSA Explorer & Visualiser - main.py

import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DSA Explorer & Visualiser")

FONT  = pygame.font.SysFont(None, 36)
SMALL = pygame.font.SysFont(None, 24)

clock = pygame.time.Clock()

# import modules
from modules.data_structures_vis import run_data_structures
from modules.sorting_vis import run_sorting
from modules.graphs_vis import run_graphs
from modules.heap_vis import run_heap
from modules.puzzles_vis import run_puzzles


def main_menu():
    screen.fill((200, 200, 250))

    title = FONT.render("DSA Explorer & Visualiser", True, (0, 0, 100))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 50))

    bw, bh = 300, 50
    bx = WIDTH // 2 - bw // 2
    buttons = {
        'Data Structures': pygame.Rect(bx, 130, bw, bh),
        'Sorting': pygame.Rect(bx, 193, bw, bh),
        'Graphs': pygame.Rect(bx, 256, bw, bh),
        'Heap': pygame.Rect(bx, 319, bw, bh),
        'Puzzles': pygame.Rect(bx, 382, bw, bh),
    }

    mouse_pos = pygame.mouse.get_pos()

    for text, rect in buttons.items():
        hovered = rect.collidepoint(mouse_pos)
        color = (180, 180, 230) if hovered else (150, 150, 200)
        pygame.draw.rect(screen, color, rect)
        label = FONT.render(text, True, (0, 0, 0))
        screen.blit(label, (rect.centerx - label.get_width() // 2, rect.centery - label.get_height() // 2))

    hint = SMALL.render("ESC inside any module returns here", True, (100, 100, 140))
    screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, 500))

    pygame.display.flip()
    return buttons


# Placeholder functions
def data_structures_module(): run_data_structures(screen, clock)
def sorting_module(): run_sorting(screen, clock)
def graphs_module(): run_graphs(screen, clock)
def heap_module(): run_heap(screen, clock)
def puzzles_module(): run_puzzles(screen, clock)


def main():
    running = True
    current_module = None
    buttons = main_menu()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and current_module is None:
                pos = event.pos
                for name, rect in buttons.items():
                    if rect.collidepoint(pos):
                        current_module = name

        if current_module is None:
            buttons = main_menu()
        else:
            dispatch = {
                'Data Structures': data_structures_module,
                'Sorting': sorting_module,
                'Graphs': graphs_module,
                'Heap': heap_module,
                'Puzzles': puzzles_module,
            }
            if current_module in dispatch:
                dispatch[current_module]()
            current_module = None # return to menu after module exits

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()


"""
References

https://www.youtube.com/watch?v=yC40jcC5o7g&list=PL1jRmGH3kUkNGae2ajJM-5gOI7VJyysl9&index=3

https://www.youtube.com/watch?v=d3Ekxkp9vvU&list=PL1jRmGH3kUkNGae2ajJM-5gOI7VJyysl9&index=7

https://www.youtube.com/watch?v=D69vgIIDLSE&list=PL1jRmGH3kUkNGae2ajJM-5gOI7VJyysl9&index=8

https://www.youtube.com/watch?v=v85ts-yOGLw&list=PL1jRmGH3kUkNGae2ajJM-5gOI7VJyysl9&index=9

https://www.youtube.com/watch?v=3yUPeIayvfU

https://www.youtube.com/watch?v=yVtGJ0uIeGc

https://www.youtube.com/watch?v=m8u533opxpM

https://coderraj07.medium.com/dynamic-programming-dp-on-grids-complete-guide-a141549b829f

https://www.geeksforgeeks.org/dsa/dp-on-grids/

https://medium.com/@aggorjefferson/building-an-a-pathfinding-visualizer-in-python-with-pygame-a2cb3502f49e

https://brandonkindred.medium.com/mastering-pathfinding-the-essentials-of-dijkstra-and-a-algorithms-691b226e71c4

"""