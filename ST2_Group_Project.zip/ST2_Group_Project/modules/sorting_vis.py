# Phase 2 - Sorting

import pygame, sys, random
from modules.toolbar import draw_toolbar, Button, BAR_HEIGHT

WHITE = (255, 255, 255) 
BLACK = (0, 0, 0) 
RED = (255, 50, 50) 
GREEN = (0, 255, 0) 
CYAN = (100, 200, 250)  # bar colour

N_BARS = 60  # number of bars
FONT = SMALL = None

def _fonts():
    global FONT, SMALL
    if FONT is None:
        FONT = pygame.font.SysFont(None, 30) 
        SMALL = pygame.font.SysFont(None, 22) 

def _bar_w(screen):
    return (screen.get_width() - 60) // N_BARS

def _arr(screen):
    max_h = screen.get_height() - BAR_HEIGHT - 80
    return [random.randint(20, max_h) for _ in range(N_BARS)]

def _draw_bars(screen, arr, states):
    bw = _bar_w(screen)
    ox = 30
    h = screen.get_height()
    for i, val in enumerate(arr):
        if states[i] == 0: color = RED
        elif states[i] == 2: color = GREEN
        else: color = CYAN
        x = ox + i * bw
        y = h - BAR_HEIGHT - val
        pygame.draw.rect(screen, color, (x, y, bw - 2, val))


# BUBBLE SORT
def run_bubble_sort(screen, clock):
    _fonts()
    h_arr = _arr(screen); states = [1]*N_BARS; counter = 0
    running = False; status = "Click Start"

    btn_start = Button(10, 10, 100, 36, "Start", (40,160,60))
    btn_reset = Button(120, 10, 100, 36, "Reset", (80,80,120))
    btn_back = Button(screen.get_width()-130, 10, 120, 36, "Back", (80,80,100))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return
            if btn_start.clicked(event): running = True; status = "Running…"
            if btn_reset.clicked(event):
                h_arr = _arr(screen); states = [1]*N_BARS
                counter = 0; running = False; status = "Reset - click Start"
            if btn_back.clicked(event): return

        if running and counter < N_BARS:
            for j in range(N_BARS - 1 - counter):
                if h_arr[j] > h_arr[j+1]:
                    states[j] = 0; states[j+1] = 0
                    h_arr[j], h_arr[j+1] = h_arr[j+1], h_arr[j]
                else:
                    states[j] = 1; states[j+1] = 1
            counter += 1
            if N_BARS - counter >= 0: states[N_BARS - counter] = 2
            status = f"Pass {counter}/{N_BARS}"
        elif running:
            status = "Complete"; running = False

        screen.fill(BLACK)
        btn_start.draw(screen); btn_reset.draw(screen); btn_back.draw(screen)
        _draw_bars(screen, h_arr, states)
        draw_toolbar(screen, algorithm = "Bubble Sort  O(n²)", 
                     status = status, 
                     controls = "Red = Comparing  |  Green = Sorted  |  ESC = Back")
        clock.tick(20); pygame.display.flip()


# SELECTION SORT
def run_selection_sort(screen, clock):
    _fonts()
    h_arr = _arr(screen); states = [1]*N_BARS; counter = 0
    running = False; status = "Click Start"

    btn_start = Button(10, 10, 100, 36, "Start", (40,160,60))
    btn_reset = Button(120,10, 100, 36, "Reset", (80,80,120))
    btn_back = Button(screen.get_width()-130, 10, 120, 36, "Back", (80,80,100))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return
            if btn_start.clicked(event): running = True; status = "Running…"
            if btn_reset.clicked(event):
                h_arr = _arr(screen); states = [1]*N_BARS
                counter = 0; running = False; status = "Reset - click Start"
            if btn_back.clicked(event): return

        if running and counter < N_BARS:
            min_idx = counter
            for j in range(counter+1, N_BARS):
                if h_arr[min_idx] > h_arr[j]: states[j] = 0; min_idx = j
                else: states[j] = 1; states[min_idx] = 1
            h_arr[counter], h_arr[min_idx] = h_arr[min_idx], h_arr[counter]
            counter += 1
            if counter-1 < N_BARS: states[counter-1] = 2
            status = f"Pass {counter}/{N_BARS}"
        elif running:
            status = "Complete"; running = False

        screen.fill(BLACK)
        btn_start.draw(screen); btn_reset.draw(screen); btn_back.draw(screen)
        _draw_bars(screen, h_arr, states)
        draw_toolbar(screen, algorithm = "Selection Sort  O(n²)", 
                     status = status,
                     controls = "Red = Min candidate  |  Green = Placed  |  ESC = Back")
        clock.tick(30); pygame.display.flip()


# QUICKSORT
def run_quicksort(screen, clock):
    _fonts()
    h_arr = _arr(screen); states = [1]*N_BARS
    j = 0; flag = False; status = "Click Start"

    def partition(arr, start, end):
        for i in range(start, end): states[i] = 0
        i = start; pivot = arr[end]; states[start] = 0
        for jj in range(start, end):
            if arr[jj] < pivot:
                arr[i], arr[jj] = arr[jj], arr[i]
                states[i] += 1; i += 1; states[i] = 0
        arr[i], arr[end] = arr[end], arr[i]
        return i

    stk = [0]*(N_BARS); top = 0; stk[top] = 0; top += 1; stk[top] = N_BARS-1

    btn_start = Button(10, 10, 100, 36, "Start", (40,160,60))
    btn_reset = Button(120,10, 100, 36, "Reset", (80,80,120))
    btn_back = Button(screen.get_width()-130, 10, 120, 36, "Back", (80,80,100))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return
            if btn_start.clicked(event): flag = True; status = "Running…"
            if btn_reset.clicked(event):
                h_arr = _arr(screen); states = [1]*N_BARS
                stk[:] = [0]*N_BARS; top = 0; stk[top] = 0; top += 1; stk[top] = N_BARS-1
                j = 0; flag = False; status = "Reset - click Start"
            if btn_back.clicked(event): return

        if flag:
            if top >= 0:
                end_ = stk[top]; top -= 1; start_ = stk[top]; top -= 1
                p = partition(h_arr, start_, end_); states[p] = 1
                if p-1 > start_: top += 1; stk[top] = start_; top += 1; stk[top] = p-1
                if p+1 < end_:   top += 1; stk[top] = p + 1;    top += 1; stk[top] = end_
            else:
                if j < N_BARS: states[j] = 2; j += 1
                else: status = "Complete"; flag = False

        screen.fill(BLACK)
        btn_start.draw(screen); btn_reset.draw(screen); btn_back.draw(screen)
        _draw_bars(screen, h_arr, states)
        draw_toolbar(screen, algorithm = "QuickSort  O(n log n) avg", 
                     status = status,
                     controls = "ESC = Back")
        clock.tick(60); pygame.display.flip()


# INSERTION SORT
def run_insertion_sort(screen, clock):
    _fonts()
    h_arr = _arr(screen); states = [1]*N_BARS; counter = 0
    running = False; status = "Click Start"

    btn_start = Button(10, 10, 100, 36, "Start", (40,160,60))
    btn_reset = Button(120,10, 100, 36, "Reset", (80,80,120))
    btn_back = Button(screen.get_width()-130, 10, 120, 36, "Back", (80,80,100))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return
            if btn_start.clicked(event): running = True; status = "Running…"
            if btn_reset.clicked(event):
                h_arr = _arr(screen); states = [1]*N_BARS
                counter = 0; running = False; status = "Reset - click Start"
            if btn_back.clicked(event): return

        if running and counter < N_BARS:
            key = h_arr[counter]; j = counter - 1
            states[counter] = 0
            while j >= 0 and key < h_arr[j]:
                h_arr[j+1] = h_arr[j]; states[j] = 0; j -= 1
            h_arr[j+1] = key; counter += 1
            status = f"Step {counter}/{N_BARS}"
        elif running:
            states = [2]*N_BARS; status = "Complete"; running = False

        screen.fill(BLACK)
        btn_start.draw(screen); btn_reset.draw(screen); btn_back.draw(screen)
        _draw_bars(screen, h_arr, states)
        draw_toolbar(screen, algorithm = "Insertion Sort  O(n²)", 
                     status = status,
                     controls = "ESC = Back")
        clock.tick(60); pygame.display.flip()


# MERGE SORT
def run_merge_sort(screen, clock):
    _fonts()
    h_arr = _arr(screen); steps = []; work = h_arr[:]

    def build(arr, lo, hi):
        if hi - lo <= 1: return
        mid = (lo+hi)//2; build(arr, lo, mid); build(arr, mid, hi)
        L = arr[lo:mid]; R = arr[mid:hi]; i = j = 0; k = lo
        while i < len(L) and j < len(R):
            if L[i] <= R[j]: arr[k] = L[i]; i += 1
            else:           arr[k] = R[j]; j += 1
            steps.append((arr[:], k)); k += 1
        while i < len(L): arr[k] = L[i]; i += 1; steps.append((arr[:],k)); k += 1
        while j < len(R): arr[k] = R[j]; j += 1; steps.append((arr[:],k)); k += 1

    build(work, 0, N_BARS); steps.append((work[:], -1))
    idx = 0; running = False; status = "Click Start"

    btn_start = Button(10, 10, 100, 36, "Start", (40,160,60))
    btn_reset = Button(120,10, 100, 36, "Reset", (80,80,120))
    btn_back = Button(screen.get_width()-130, 10, 120, 36, "Back", (80,80,100))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return
            if btn_start.clicked(event): running = True; status = "Running…"
            if btn_reset.clicked(event):
                h_arr = _arr(screen); steps = []; work = h_arr[:]
                build(work, 0, N_BARS); steps.append((work[:], -1))
                idx = 0; running = False; status = "Reset - click Start"
            if btn_back.clicked(event): return

        if running and idx < len(steps):
            cur, active = steps[idx]; idx += 1
        elif running:
            cur, active = steps[-1]; status = "Complete"; running = False
        else:
            cur, active = steps[min(idx, len(steps)-1)]

        st = [0 if i == active else (2 if idx >= len(steps) else 1) for i in range(len(cur))]

        screen.fill(BLACK)
        btn_start.draw(screen); btn_reset.draw(screen); btn_back.draw(screen)
        _draw_bars(screen, cur, st)
        draw_toolbar(screen, algorithm = "Merge Sort  O(n log n)", 
                     status = status,
                     controls = "Red = Merging  |  Green = Sorted  |  ESC = Back")
        clock.tick(60); pygame.display.flip()


# SUB MENU
def run_sorting(screen, clock):
    _fonts()
    font = pygame.font.SysFont(None, 34)
    small = pygame.font.SysFont(None, 20)
    W = screen.get_width()
    items = [
        ("Bubble Sort", run_bubble_sort),
        ("Selection Sort", run_selection_sort),
        ("QuickSort", run_quicksort),
        ("Insertion Sort", run_insertion_sort),
        ("Merge Sort", run_merge_sort),
        ("Back", None),
    ]
    buttons = [Button(W // 2-140, 95 + i * 54, 280, 44, lbl, (80,100,160)) for i,(lbl,_) in enumerate(items)]
    buttons[-1].color = (80, 80, 100)

    while True:
        screen.fill((200, 200, 250))
        title = font.render("Sorting Algorithms - Phase 2", True, (0,0,100))
        screen.blit(title, (W//2 - title.get_width()//2, 35))
        for b in buttons:
            b.draw(screen)
        draw_toolbar(screen, algorithm = "Phase 2 - Sorting", 
                     status = "",
                     controls = "Click a module  |  ESC = Back")
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return
            for b, (_, fn) in zip(buttons, items):
                if b.clicked(event):
                    if fn is None: return
                    fn(screen, clock)
        clock.tick(30)