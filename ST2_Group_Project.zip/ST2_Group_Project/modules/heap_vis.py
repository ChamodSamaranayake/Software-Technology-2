# Phase 2 - Heap Visualizer

import pygame, sys, random, math
from modules.toolbar import draw_toolbar, Button, BAR_HEIGHT

WIDTH, HEIGHT = 800, 600
FONT = SMALL = None

def _fonts():
    global FONT, SMALL
    if FONT is None:
        FONT = pygame.font.SysFont(None, 26)
        SMALL = pygame.font.SysFont(None, 20)

heap = []   # global max-heap array


# Draw_heap
def draw_heap(screen, h, highlight_indices=None):
    if highlight_indices is None: highlight_indices = []
    pygame.draw.rect(screen, (255,255,255), (0, 0, WIDTH//2, HEIGHT - BAR_HEIGHT))

    if not h:
        t = FONT.render("Heap is empty", True, (0,0,0))
        screen.blit(t, (WIDTH//4 - t.get_width()//2, HEIGHT//2))
        return

    node_positions = []
    for i in range(len(h)):
        level = int(math.floor(math.log2(i + 1)))
        idx_in_level = i - (2 ** level - 1)
        gap = (WIDTH//2) // (2 ** level + 1)
        x = gap * (idx_in_level + 1)
        y = 90 + level * 70
        node_positions.append((x, y))

    # Draw edges
    for i in range(len(h)):
        for child in [2*i+1, 2*i+2]:
            if child < len(h):
                pygame.draw.line(screen, (0,0,0), node_positions[i], node_positions[child], 2)

    # Draw nodes
    for i, val in enumerate(h):
        if i in highlight_indices: color = (255, 100, 100)   # swapping – red
        elif i == 0: color = (255, 200,  60)   # root - gold
        else: color = (100, 200, 250)   # normal – blue
        pygame.draw.circle(screen, color, node_positions[i], 20)
        pygame.draw.circle(screen, (0,0,0), node_positions[i], 20, 1)
        t = FONT.render(str(val), True, (0,0,0))
        screen.blit(t, t.get_rect(center=node_positions[i]))


# Array view
def _draw_array(screen, h, hi = []):
    ay = HEIGHT - BAR_HEIGHT - 58
    pygame.draw.rect(screen, (255,255,255), (0, ay-24, WIDTH//2, 82))
    screen.blit(SMALL.render("Heap array (Index 0 = Root = Max):", True, (0,0,0)), (10, ay-20))
    for i, v in enumerate(h):
        rx  = 10 + i*36
        col = (255,100,100) if i in hi else (180,220,255)
        pygame.draw.rect(screen, col, (rx, ay, 32, 28), border_radius = 4)
        pygame.draw.rect(screen, (0,0,0), (rx, ay, 32, 28), 1, border_radius = 4)
        screen.blit(SMALL.render(str(v), True, (0,0,0)),
                    (rx + 16 - SMALL.size(str(v))[0]//2, ay+5))
        screen.blit(SMALL.render(str(i), True, (120,120,120)),
                    (rx + 16 - SMALL.size(str(i))[0]//2, ay+32))


def _refresh(screen, clock, h, hi = [], status = ""):
    draw_heap(screen, h, hi)
    _draw_array(screen, h, hi)
    draw_toolbar(screen, algorithm = "Max - Heap", status = status, controls = "")
    pygame.display.flip()
    for event in pygame.event.get():
        if event.type == pygame.QUIT: pygame.quit(); sys.exit()
    clock.tick(30)


# Sift UP
def heapify_up(screen, clock, h, index):
    while index > 0:
        parent = (index - 1) // 2
        if h[index] > h[parent]:      # child exceeds parent – violates heap condition
            _refresh(screen, clock, h, [index, parent], f"Sift-up: {h[index]} > {h[parent]}, swapping")
            pygame.time.wait(350)
            h[index], h[parent] = h[parent], h[index]
            index = parent
        else:
            break
    _refresh(screen, clock, h, [], "Heap condition restored")


# Sift DOWN
def heapify_down(screen, clock, h, index):
    n = len(h)
    while True:
        l, r, largest = 2*index+1, 2*index+2, index
        if l < n and h[l] > h[largest]: largest = l
        if r < n and h[r] > h[largest]: largest = r
        if largest != index:
            _refresh(screen, clock, h, [index, largest],
                     f"Sift-down: {h[index]} < {h[largest]}, swapping")
            pygame.time.wait(350)
            h[index], h[largest] = h[largest], h[index]
            index = largest
        else:
            break
    _refresh(screen, clock, h, [], "Heap condition restored")


# Insert
def heap_insert(screen, clock, h, val):
    h.append(val)
    _refresh(screen, clock, h, [len(h)-1], f"Inserted {val} at end (index {len(h)-1})")
    pygame.time.wait(300)
    heapify_up(screen, clock, h, len(h)-1)


# Remove max
def heap_remove_max(screen, clock, h):
    if not h: return None
    max_val = h[0]
    last = h.pop()
    if h:
        h[0] = last
        _refresh(screen, clock, h, [0], f"Removed max = {max_val}, moved last ({last}) to root")
        pygame.time.wait(350)
        heapify_down(screen, clock, h, 0)
    return max_val


# Silent heapify for seeding
def _sift_up_silent(h, i):
    while i > 0:
        p = (i-1) // 2
        if h[i] > h[p]: h[i], h[p] = h[p], h[i]; i = p
        else: break


# Main heap module
def run_heap(screen, clock):
    _fonts()
    global heap; heap = []
    font  = pygame.font.SysFont(None, 30)
    small = pygame.font.SysFont(None, 18)

    # Put random values
    for v in [random.randint(1, 99) for _ in range(8)]:
        heap.append(v); _sift_up_silent(heap, len(heap) - 1)

    inp = ""; inp_active = False
    status = "Max-Heap loaded  -  largest value is always at the root"

    # Buttons
    btn_ins = Button(10, 10, 100, 34, "Insert", (40,140,60))
    btn_rnd = Button(120, 10, 130, 34, "Insert Random", (0,100,180))
    btn_rem = Button(260, 10, 130, 34, "Remove Max", (180,40,40))
    btn_back = Button(WIDTH-130, 10, 120, 34, "Back", (80,80,100))
    inp_r = pygame.Rect(10, 52, 80, 28)

    # Info panel
    notes = [
        "MAX - HEAP",
        "",
        "Heap condition :",
        "  Parent >= Children",
        "  Largest key always at root",
        "",
        "Insert :",
        "  Append to end & Sift UP",
        "  Swap child & parent if child > parent",
        "",
        "Remove Max :",
        "  Remove root (max)",
        "  Move last node to root & Sift DOWN",
        "  Swap with largest child until fixed",

    ]

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: return
                if inp_active:
                    if event.key == pygame.K_BACKSPACE: inp = inp[:-1]
                    elif event.unicode.isdigit(): inp += event.unicode

            if event.type == pygame.MOUSEBUTTONDOWN:
                inp_active = inp_r.collidepoint(event.pos)

            if btn_ins.clicked(event):
                try:
                    v = int(inp); heap_insert(screen, clock, heap, v)
                    status = f"Inserted {v}  -  sifted up to correct position"; inp = ""
                except: status = "Click the value box and type a number first"

            if btn_rnd.clicked(event):
                v = random.randint(1, 99); heap_insert(screen, clock, heap, v)
                status = f"Inserted random value {v}"

            if btn_rem.clicked(event):
                v = heap_remove_max(screen, clock, heap)
                status = f"Removed max = {v}  -  last node moved to root, sifted down" \
                         if v is not None else "Heap is empty"
                
            if btn_back.clicked(event): return

        screen.fill((255,255,255))
        draw_heap(screen, heap)
        _draw_array(screen, heap)

        # Right info panel
        pygame.draw.rect(screen, (240,240,255), (WIDTH//2, 0, WIDTH//2, HEIGHT-BAR_HEIGHT))
        for i, ln in enumerate(notes):
            col = (0,0,140) if i == 0 else ((80,0,120) if ":" in ln and ln[0] != " " else (30,30,30))
            bold = (i == 0)
            f = pygame.font.SysFont(None, 20 if not bold else 22, bold = bold)
            screen.blit(f.render(ln, True, col), (WIDTH // 2+10, 8+i *26))

        # Input box
        pygame.draw.rect(screen, (255,255,255), inp_r, border_radius = 4)
        pygame.draw.rect(screen, (0,120,200) if inp_active else (160,160,160), inp_r, 1, border_radius = 4)
        screen.blit(small.render(inp or "value", True, (0,0,0) if inp else (160,160,160)), (inp_r.x+4, inp_r.y+7))

        for b in (btn_ins, btn_rnd, btn_rem, btn_back):
            b.draw(screen)

        draw_toolbar(screen,
                     algorithm = "Max-Heap  -  Parent >= Children",
                     status = status,
                     controls = "Gold = Root (Max)  |  Red = Swapping  |  ESC = Back")
        pygame.display.flip(); clock.tick(30)