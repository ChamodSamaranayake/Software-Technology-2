# Phase 2 - Graph Traversal

import pygame, sys, collections
from modules.toolbar import draw_toolbar, Button, BAR_HEIGHT

WIDTH, HEIGHT = 800, 600
FONT=SMALL=None
def _fonts():
    global FONT,SMALL
    if FONT is None: FONT=pygame.font.SysFont(None,30); SMALL=pygame.font.SysFont(None,22)

nodes_pos = {'A':(100,130),'B':(280,80),'C':(280,220),'D':(460,130),'E':(560,200),'F':(460,320)}
graph = {'A':['B','C'],'B':['A','D','E'],'C':['A','F'],'D':['B'],'E':['B','F'],'F':['C','E']}

def draw_graph(screen, visited = set(), frontier = set(), current = None, tree_edges = None, start_node = None):
    pygame.draw.rect(screen, (240,240,245), (0, 60, WIDTH-180, HEIGHT-BAR_HEIGHT-60))
    drawn = set()
    for node,neighbors in graph.items():
        x1, y1 = nodes_pos[node]
        for nb in neighbors:
            key = tuple(sorted([node,nb]))
            if key in drawn: continue
            drawn.add(key)
            x2, y2 = nodes_pos[nb]
            in_tree = tree_edges and key in tree_edges
            pygame.draw.line(screen, (0,180,80) if in_tree else (0,0,0), (x1,y1), (x2,y2), 3 if in_tree else 2)
    for node, (x, y) in nodes_pos.items():
        color = (200,200,200)
        if node in visited: color = (100,200,100)
        if node in frontier: color = (255,200,100)
        if node == current: color = (255,100,100)
        if node == start_node and node not in visited: color = (100,160,255)
        pygame.draw.circle(screen, color, (x,y), 25)
        pygame.draw.circle(screen, (0,0,0), (x,y), 25, 2)
        t = FONT.render(node, True, (0,0,0))
        screen.blit(t,t.get_rect(center = (x,y)))

def bfs_steps(start):
    visited = set(); queue = collections.deque([start]); tree_edges = set(); order = []
    while queue:
        current = queue.popleft()
        if current in visited: continue
        visited.add(current); order.append(current)
        yield visited.copy(),set(queue),current,tree_edges.copy(),list(order)
        for nb in sorted(graph[current]):
            if nb not in visited and nb not in queue:
                queue.append(nb); tree_edges.add(tuple(sorted([current,nb])))

def dfs_steps(start):
    visited = set(); stack = [start]; tree_edges = set(); order = []; parent = {start:None}
    while stack:
        current = stack.pop()
        if current in visited: continue
        visited.add(current); order.append(current)
        par = parent.get(current)
        if par: tree_edges.add(tuple(sorted([par,current])))
        yield visited.copy(),set(stack),current,tree_edges.copy(),list(order)
        for nb in sorted(graph[current], reverse = True):
            if nb not in visited: stack.append(nb); parent[nb] = current

def _node_at(pos):
    for name,(nx,ny) in nodes_pos.items():
        if (pos[0]-nx) **2 + (pos[1]-ny) **2 <= 25 **2: return name
    return None

def run_graphs(screen, clock):
    _fonts()
    start = 'A'; mode = 'BFS'; gen = None
    visited_s = set(); frontier_s = set(); current_n = None
    tree_edges = set(); order = []; frame_cnt = 0; step_delay = 18
    status = "Click a node to set start, then click Run"

    # On screen buttons
    btn_bfs = Button(10, 10, 90, 36, "BFS", (0,130,80))
    btn_dfs = Button(110, 10, 90, 36, "DFS", (80,80,160))
    btn_run = Button(210, 10, 110, 36, "Run", (40,160,60))
    btn_reset = Button(330, 10, 100, 36, "Reset", (80,80,120))
    btn_back = Button(WIDTH-140, 10, 130, 36, "Back", (80,80,100))

    def do_reset():
        nonlocal gen,visited_s, frontier_s, current_n, tree_edges, order, frame_cnt
        gen = None; visited_s = set(); frontier_s = set(); current_n = None
        tree_edges = set(); order = []; frame_cnt = 0

    while True:
        # Highlight active mode button
        btn_bfs.color = (0,160,100) if mode == 'BFS' else (80,100,140)
        btn_dfs.color = (80,80,200) if mode == 'DFS' else (80,100,140)

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return

            if btn_bfs.clicked(event): mode = 'BFS'; do_reset(); status = "BFS mode - click Run"
            if btn_dfs.clicked(event): mode = 'DFS'; do_reset(); status = "DFS mode - click Run"
            if btn_reset.clicked(event): do_reset(); status = "Reset - click Run"
            if btn_back.clicked(event): return
            if btn_run.clicked(event):
                do_reset()
                gen = bfs_steps(start) if mode == 'BFS' else dfs_steps(start)
                status = f"Running {mode} from '{start}'…"

            # Click a node on the graph to set start
            if event.type == pygame.MOUSEBUTTONDOWN:
                clicked = _node_at(event.pos)
                if clicked: start = clicked; do_reset(); status = f"Start set to '{start}' - click Run"

        if gen:
            frame_cnt += 1
            if frame_cnt >= step_delay:
                frame_cnt = 0
                try:
                    visited_s, frontier_s, current_n, tree_edges, order = next(gen)
                    status = f"{mode}: visited {' , '.join(order)}"
                except StopIteration:
                    gen = None; current_n = None
                    status = f"{mode} complete!  Order: {' , '.join(order)}"

        screen.fill((240,240,245))
        draw_graph(screen,visited_s,frontier_s,current_n,tree_edges,start)

        for b in (btn_bfs,btn_dfs,btn_run,btn_reset,btn_back): b.draw(screen)

        # Legend 
        ox = 630; oy = 60
        pygame.draw.rect(screen, (220,220,240), (ox, oy, 160, 120), border_radius = 6)
        for i,(col,lbl) in enumerate([((100,200,100),"Visited"),((255,200,100),"Frontier"), ((255,100,100),"Current"),((100,160,255),"Start")]):
            pygame.draw.circle(screen, col, (ox + 14, oy + 18 + i * 24), 8)
            screen.blit(SMALL.render(lbl, True, (0,0,0)), (ox + 28, oy + 10 + i * 24))

        draw_toolbar(screen,algorithm = f"Graph Traversal - {mode}",status = status,
                     controls = "Click node = Set start  |  ESC = Back")
        pygame.display.flip(); clock.tick(60)
