# toolbar.py - Common toolbar

import pygame

BAR_HEIGHT = 50
STATUS_HEIGHT = 28

BG_COLOR = (30, 30, 55)
STATUS_BG = (20, 20, 40)
TEXT_COLOR = (200, 200, 220)
STATUS_COLOR = (100, 230, 130)
HINT_COLOR = (140, 140, 170)
DIVIDER = (60, 60, 100)

_font_cache = {}
def _f(size=18):
    if size not in _font_cache:
        _font_cache[size] = pygame.font.SysFont("Arial", size)
    return _font_cache[size]


class Button:
    def __init__(self, x, y, w, h, label, color = (60, 100, 180)):
        self.rect = pygame.Rect(x, y, w, h)
        self.label = label
        self.color = color

    def draw(self, screen):
        hover = self.rect.collidepoint(pygame.mouse.get_pos())
        c = tuple(min(255, v + 35) for v in self.color) if hover else self.color
        pygame.draw.rect(screen, c, self.rect, border_radius = 7)
        pygame.draw.rect(screen, (200,200,220), self.rect, 1, border_radius = 7)
        t = _f(17).render(self.label, True, (255, 255, 255))
        screen.blit(t, (self.rect.centerx - t.get_width()  // 2, self.rect.centery - t.get_height() // 2))

    def clicked(self, event):
        return (event.type == pygame.MOUSEBUTTONDOWN and
                event.button == 1 and
                self.rect.collidepoint(event.pos))


def draw_toolbar(screen, algorithm = "", status = "", controls = ""):
    W = screen.get_width()
    H = screen.get_height()

    # Status bar (above the main toolbar) 
    sy = H - BAR_HEIGHT - STATUS_HEIGHT
    pygame.draw.rect(screen, STATUS_BG, (0, sy, W, STATUS_HEIGHT))
    pygame.draw.line(screen, DIVIDER, (0, sy), (W, sy), 1)
    if status:
        t = _f(16).render(status, True, STATUS_COLOR)
        screen.blit(t, (W//2 - t.get_width()//2, sy + STATUS_HEIGHT//2 - t.get_height()//2))

    # Main toolbar (algorithm left, controls right) 
    ty = H - BAR_HEIGHT
    pygame.draw.rect(screen, BG_COLOR, (0, ty, W, BAR_HEIGHT))
    pygame.draw.line(screen, DIVIDER,  (0, ty), (W, ty), 2)
    if algorithm:
        t = _f(17).render(algorithm, True, TEXT_COLOR)
        screen.blit(t, (10, ty + BAR_HEIGHT//2 - t.get_height()//2))
    if controls:
        t = _f(14).render(controls, True, HINT_COLOR)
        screen.blit(t, (W - t.get_width() - 10, ty + BAR_HEIGHT//2 - t.get_height()//2))