# Phase 1 - Data Structures Visualiser

import pygame, sys
from modules.stack   import Stack
from modules.toolbar import draw_toolbar, Button, BAR_HEIGHT

BG_DARK = (50,  50,  50)
BG_LIGHT = (240, 240, 240)
BLUE = (100, 150, 250)
RED_HI = (255, 100, 100)
GREEN_HI = (80,  200, 100)
ORANGE = (255, 165,  50)
WHITE = (255, 255, 255)
BLACK = (0,   0,   0)
GRAY = (160, 160, 160)

BLOCK_W, BLOCK_H = 200, 40
W, H = 800, 600

def _font(s=28): return pygame.font.SysFont(None, s)


# STACK
def run_stack_vis(screen, clock):
    font = _font(28); small = _font(22)
    stack = Stack(max_size=8); counter = 1
    START_X = (W - BLOCK_W) // 2
    BASE_Y  = H - BLOCK_H - BAR_HEIGHT - 40
    status = "Use the Red and Green buttons to push and pop items"

    btn_push = Button(50, 20, 150, 42, f"Push {counter}", (40, 160, 60))
    btn_pop = Button(215, 20, 150, 42, "Pop", (180, 50, 50))
    btn_back = Button(W-160, 20, 140, 42, "Back", (80, 80, 100))

    while True:
        btn_push.label = f"Push  {counter}"

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return

            if btn_push.clicked(event):
                try: stack.push(counter); status = f"Pushed {counter}"; counter += 1
                except OverflowError: status = "Stack is FULL!"

            if btn_pop.clicked(event):
                try: v = stack.pop(); status = f"Popped  {v}"
                except IndexError: status = "Stack is EMPTY!"

            if btn_back.clicked(event): return

        screen.fill(BG_DARK)
        btn_push.draw(screen)
        btn_pop.draw(screen)
        btn_back.draw(screen)

        screen.blit(small.render(f"Size: {stack.size()} / {stack.max_size}", True, WHITE), (10, 72))
        screen.blit(small.render("TOP = Most recently pushed item", True, GRAY), (10, 96))

        for i, val in enumerate(stack.to_list()):
            rect = pygame.Rect(START_X, BASE_Y - i*(BLOCK_H+5), BLOCK_W, BLOCK_H)
            pygame.draw.rect(screen, BLUE, rect)
            t = font.render(str(val), True, BLACK)
            screen.blit(t, t.get_rect(center=rect.center))
            if i == stack.size()-1:
                screen.blit(small.render("TOP", True, ORANGE), (rect.right+8, rect.y+10))

        draw_toolbar(screen,
                     algorithm = "Stack  -  LIFO",
                     status = status,
                     controls = "ESC = Back")
        pygame.display.flip(); clock.tick(30)


# QUEUE
class _Queue:
    MAX = 8
    def __init__(self): self.data = []
    def enqueue(self, v):
        if len(self.data) >= self.MAX: return False
        self.data.append(v); return True
    def dequeue(self): return self.data.pop(0) if self.data else None

def run_queue_vis(screen, clock):
    font = _font(28); small = _font(22)
    q = _Queue(); ctr = 1; status = "Use the Red and Green buttons to enqueue and dequeue"
    slide_offset = 0
    BW, BH = 70, 50; QY = 280

    btn_enq = Button(50, 20, 170, 42, f"Enqueue  {ctr}", (40, 160, 60))
    btn_deq = Button(235, 20, 190, 42, "Dequeue (front)", (180, 50, 50))
    btn_back = Button(W-160, 20, 140, 42, "Back", (80, 80, 100))

    while True:
        btn_enq.label = f"Enqueue  {ctr}"
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return

            if btn_enq.clicked(event):
                if q.enqueue(ctr): status = f"Enqueued {ctr}"; ctr += 1
                else: status = "Queue is FULL!"

            if btn_deq.clicked(event):
                v = q.dequeue()
                if v is not None: status = f"Dequeued {v} from front"; slide_offset = 30
                else: status = "Queue is EMPTY!"

            if btn_back.clicked(event): return

        if slide_offset > 0: slide_offset = max(0, slide_offset - 4)

        screen.fill(BG_DARK)
        btn_enq.draw(screen); btn_deq.draw(screen); btn_back.draw(screen)
        screen.blit(small.render(f"Size: {len(q.data)} / {_Queue.MAX}", True, WHITE), (10, 72))

        for i, v in enumerate(q.data):
            x = 40 + i*(BW+8) - slide_offset
            col = GREEN_HI if i == 0 else BLUE
            pygame.draw.rect(screen, col, (x, QY, BW, BH), border_radius=6)
            pygame.draw.rect(screen, WHITE, (x, QY, BW, BH), 1, border_radius=6)
            t = font.render(str(v), True, BLACK if col==GREEN_HI else WHITE)
            screen.blit(t, (x+BW//2-t.get_width()//2, QY+BH//2-t.get_height()//2))
        if q.data:
            screen.blit(small.render("FRONT", True, GREEN_HI), (40, QY-26))
            screen.blit(small.render("REAR", True, ORANGE),
                        (40+(len(q.data)-1)*(BW+8), QY-26))

        draw_toolbar(screen,
                     algorithm = "Queue  -  FIFO",
                     status=status,
                     controls="ESC = Back")
        pygame.display.flip(); clock.tick(60)


# LINKED LIST
class _LLNode:
    def __init__(self, v): self.value = v; self.next = None

class _LL:
    def __init__(self): self.head = None
    def append(self, v):
        n = _LLNode(v)
        if not self.head: self.head = n; return
        c = self.head
        while c.next: c = c.next
        c.next = n
    def insert_at(self, v, pos):
        n = _LLNode(v)
        # clamp pos to valid range
        length = len(self.to_list())
        pos = max(0, min(pos, length))
        if pos == 0: n.next = self.head; self.head = n; return
        c = self.head; i = 0
        while c and i < pos-1: c = c.next; i += 1
        if c: n.next = c.next; c.next = n
    def delete_head(self):
        if self.head: v = self.head.value; self.head = self.head.next; return v
        return None
    def reverse(self):
        p = None; c = self.head
        while c: n = c.next; c.next = p; p = c; c = n
        self.head = p
    def to_list(self):
        r = []; c = self.head
        while c: r.append(c.value); c = c.next
        return r

NODE_R = 25
def _draw_node(screen, font, x, y, value):
    pygame.draw.circle(screen, (100, 200, 250), (x, y), NODE_R)
    t = font.render(str(value), True, BLACK)
    screen.blit(t, t.get_rect(center=(x, y)))

def _draw_arrow(screen, start, end):
    pygame.draw.line(screen, BLACK, start, end, 3)
    pygame.draw.polygon(screen, BLACK, [(end[0]-10, end[1]-5), end, (end[0]-10, end[1]+5)])

def run_linked_list_vis(screen, clock):
    font = _font(26); small = _font(20)
    ll = _LL()
    for v in [5, 10, 15, 20]: ll.append(v)
    status = "Linked list loaded: 5 , 10 , 15 , 20"; ctr = 25
    inp = ""; pos_inp = "0"; inp_active = pos_active = False

    btn_append = Button(10, 10, 120, 36, "Append", (40, 140, 60))
    btn_insert = Button(140, 10, 145, 36, "Insert from pos", (40, 100, 180))
    btn_del = Button(295, 10, 130, 36, "Delete Head", (180, 50, 50))
    btn_rev = Button(435, 10, 110, 36, "Reverse", (130, 60, 180))
    btn_back = Button(W-150, 10, 135, 36, "Back", (80, 80, 100))

    inp_r = pygame.Rect(45,  54, 80, 28)
    pos_r = pygame.Rect(185, 54, 70, 28)
    NY = 180

    while True:
        btn_append.label = f"Append {ctr}"
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: return
                if inp_active:
                    if event.key == pygame.K_BACKSPACE: inp = inp[:-1]
                    elif event.unicode.isdigit(): inp += event.unicode
                elif pos_active:
                    if event.key == pygame.K_BACKSPACE: pos_inp = pos_inp[:-1]
                    elif event.unicode.isdigit(): pos_inp += event.unicode
            if event.type == pygame.MOUSEBUTTONDOWN:
                inp_active = inp_r.collidepoint(event.pos)
                pos_active = pos_r.collidepoint(event.pos)

            if btn_append.clicked(event):
                ll.append(ctr); status = f"Appended {ctr}"; ctr += 5
            if btn_insert.clicked(event):
                try:
                    v = int(inp) if inp else ctr
                    p = int(pos_inp) if pos_inp else 0
                    length = len(ll.to_list())
                    p = max(0, min(p, length))   # clamp to valid range
                    ll.insert_at(v, p)
                    status = f"Inserted {v} at position {p}"
                    inp = ""
                except:
                    status = "Invalid input in boxes"
            if btn_del.clicked(event):
                v = ll.delete_head()
                status = f"Deleted head ({v})" if v is not None else "List is empty"
            if btn_rev.clicked(event):
                ll.reverse(); status = "List reversed!"
            if btn_back.clicked(event): return

        screen.fill(BG_LIGHT)
        for b in (btn_append, btn_insert, btn_del, btn_rev, btn_back): b.draw(screen)

        screen.blit(small.render("val :", True, BLACK), (10, inp_r.y + 5))
        pygame.draw.rect(screen, WHITE, inp_r, border_radius = 4)
        pygame.draw.rect(screen, (0,120,200) if inp_active else GRAY, inp_r, 1, border_radius = 4)
        screen.blit(small.render(inp, True, BLACK if inp else GRAY), (inp_r.x+4, inp_r.y+5))

        screen.blit(small.render("pos :", True, BLACK), (150, pos_r.y + 5))
        pygame.draw.rect(screen, WHITE, pos_r, border_radius = 4)
        pygame.draw.rect(screen, (0,120,200) if pos_active else GRAY, pos_r, 1, border_radius = 4)
        screen.blit(small.render(pos_inp, True, BLACK), (pos_r.x+4, pos_r.y+5))

        nodes = ll.to_list(); x = 60; y = NY
        for i, v in enumerate(nodes):
            _draw_node(screen, small, x, y, v)
            if i < len(nodes)-1:
                _draw_arrow(screen, (x+NODE_R, y), (x+130-NODE_R, y))
            x += 130
        if nodes:
            screen.blit(small.render("NULL", True, RED_HI), (x, y-10))
            screen.blit(small.render("HEAD", True, (0,120,200)), (60-18, NY-40))

        draw_toolbar(screen,
                     algorithm = "Linked List  -  Singly Linked",
                     status = status,
                     controls = "Click val/pos boxes to type, then click action button  |  ESC = Back")
        pygame.display.flip(); clock.tick(30)


#  BST
NODE_RB = 20

class _BSTNode:
    def __init__(self, v): self.value = v; self.left = self.right = None

class _BST:
    def __init__(self): self.root = None
    def insert(self, v): self.root = self._ins(self.root, v)
    def _ins(self, n, v):
        if not n: return _BSTNode(v)
        if v < n.value: n.left  = self._ins(n.left,  v)
        elif v > n.value: n.right = self._ins(n.right, v)
        return n
    def inorder(self): r=[]; self._in(self.root,r); return r
    def preorder(self): r=[]; self._pre(self.root,r); return r
    def postorder(self): r=[]; self._po(self.root,r); return r
    def _in(self,n,r):
        if n: self._in(n.left,r); r.append(n); self._in(n.right,r)
    def _pre(self,n,r):
        if n: r.append(n); self._pre(n.left,r); self._pre(n.right,r)
    def _po(self,n,r):
        if n: self._po(n.left,r); self._po(n.right,r); r.append(n)
    def search_path(self, v):
        path = []; cur = self.root
        while cur:
            path.append(cur)
            if v == cur.value: break
            elif v < cur.value: cur = cur.left
            else: cur = cur.right
        return path

def _draw_tree(screen, font, node, x, y, x_offset, positions, parent_pos=None):
    if node:
        positions[node] = (x, y)
        if parent_pos: pygame.draw.line(screen, BLACK, parent_pos, (x,y), 3) 
        _draw_tree(screen, font, node.left, x-x_offset, y+80, x_offset//2, positions, (x,y)) 
        _draw_tree(screen, font, node.right, x+x_offset, y+80, x_offset//2, positions, (x,y)) 
        color = (255,150,150) if getattr(node,'_hi',False) else (100,200,250) 
        pygame.draw.circle(screen, color, (x,y), NODE_RB) 
        t = font.render(str(node.value), True, BLACK) 
        screen.blit(t, t.get_rect(center=(x,y))) 

def run_bst_vis(screen, clock):
    font = _font(22); small = _font(18)
    bst = _BST()
    for v in [50, 30, 70, 20, 40, 60, 80]: bst.insert(v)
    inp = ""; trav_text = ""; highlight = []
    status = "BST loaded with 50, 30, 70, 20, 40, 60, 80"; inp_active = False

    btn_insert = Button(10, 10, 100, 32, "Insert", (40,140,60))
    btn_inorder = Button(120, 10, 100, 32, "In-order", (40,100,180))
    btn_pre = Button(230, 10, 110, 32, "Pre-order", (100,60,180))
    btn_post = Button(350, 10, 115, 32, "Post-order",(180,80,40))
    btn_search = Button(475, 10, 100, 32, "Search", (180,140,40))
    btn_back = Button(W-145, 10, 135, 32, "Back", (80,80,100))
    inp_r = pygame.Rect(10, 70, 95, 28)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: return
                if inp_active:
                    if event.key == pygame.K_BACKSPACE: inp = inp[:-1]
                    elif event.unicode.isdigit(): inp += event.unicode
            if event.type == pygame.MOUSEBUTTONDOWN:
                inp_active = inp_r.collidepoint(event.pos)

            if btn_insert.clicked(event):
                try: v = int(inp); bst.insert(v); status = f"Inserted {v}"; inp = ""; highlight = []
                except: status = "Type a number in the box, then click Insert"
            if btn_inorder.clicked(event):
                trav_text = "In-order: "+" , ".join(str(n.value) for n in bst.inorder())
                status = "In-order traversal  (Left -> Root -> Right)"; highlight = []
            if btn_pre.clicked(event):
                trav_text = "Pre-order: "+" , ".join(str(n.value) for n in bst.preorder())
                status = "Pre-order traversal  (Root -> Left -> Right)"; highlight = []
            if btn_post.clicked(event):
                trav_text = "Post-order: "+" , ".join(str(n.value) for n in bst.postorder())
                status = "Post-order traversal  (Left -> Right -> Root)"; highlight = []
            if btn_search.clicked(event):
                try:
                    v = int(inp); path=bst.search_path(v); highlight = path
                    found = path and path[-1].value == v
                    status = f"Search {v}:  {'FOUND' if found else 'Not found'}"
                except: status = "Type a number in the box, then click Search"
            if btn_back.clicked(event): return

        screen.fill(BG_LIGHT)
        for b in (btn_insert, btn_inorder, btn_pre, btn_post, btn_search, btn_back): b.draw(screen)

        screen.blit(small.render("Value:", True, BLACK), (10, 55)) 
        pygame.draw.rect(screen, WHITE, inp_r, border_radius=4) 
        pygame.draw.rect(screen, (0,120,200) if inp_active else GRAY, inp_r, 1, border_radius=4) 
        screen.blit(small.render(inp or "Type here", True, BLACK if inp else GRAY), (inp_r.x+4, inp_r.y+5)) 

        if trav_text:
            screen.blit(small.render(trav_text, True, (0,0,180)), (10, 105))

        positions = {}
        for n in highlight: n._hi = True
        _draw_tree(screen, small, bst.root, W//2, 130, 150, positions)
        for n in highlight: n._hi = False

        draw_toolbar(screen,
                     algorithm = "Binary Search Tree  -  Left < Root < Right",
                     status = status,
                     controls = "Click value box then type number then click action button  |  ESC = Back")
        pygame.display.flip(); clock.tick(30)


# SUB MENU
def run_data_structures(screen, clock):
    font = pygame.font.SysFont(None, 36)
    items = [
        ("Stack Visualizer", run_stack_vis),
        ("Queue Visualizer", run_queue_vis),
        ("Linked List Visualizer", run_linked_list_vis),
        ("BST Visualizer", run_bst_vis),
        ("Back to Main Menu", None),
    ]
    buttons = [Button(240, 105+i*58, 320, 46, lbl, (80,100,160)) for i,(lbl,_) in enumerate(items)]
    buttons[-1].color = (80, 80, 100)

    while True:
        screen.fill((200, 200, 250))
        title = font.render("Data Structures Playground - Phase 1", True, (0,0,100))
        screen.blit(title, (W//2 - title.get_width()//2, 35))
        for b in buttons:
            b.draw(screen)
        draw_toolbar(screen, algorithm = "Phase 1 - Data Structures", status = "",
                     controls = "Click a module to launch it  |  ESC = Back")
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return
            for b, (_, fn) in zip(buttons, items):
                if b.clicked(event):
                    if fn is None: return
                    fn(screen, clock)
        clock.tick(30)