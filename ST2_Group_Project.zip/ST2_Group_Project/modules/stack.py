# stack.py 


class Stack:
    def __init__(self, max_size=20):
        self._data     = []
        self.max_size  = max_size

    def push(self, value):
        if len(self._data) >= self.max_size:
            raise OverflowError("Stack is full")
        self._data.append(value)

    def pop(self):
        if self.is_empty():
            raise IndexError("Pop from empty stack")
        return self._data.pop()

    def peek(self):
        if self.is_empty():
            raise IndexError("Peek on empty stack")
        return self._data[-1]

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)

    def to_list(self):
        # Bottom to top
        return list(self._data)
