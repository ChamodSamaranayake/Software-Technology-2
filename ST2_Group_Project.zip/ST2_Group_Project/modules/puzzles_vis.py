# Phase 3 - Puzzles

import pygame, sys, math, random
from collections import deque
from modules.toolbar import draw_toolbar, Button, BAR_HEIGHT

WIDTH, HEIGHT = 800, 600
FONT = SMALL = None
def _fonts():
    global FONT,SMALL
    if FONT is None: FONT = pygame.font.SysFont(None,30); SMALL = pygame.font.SysFont(None,20)

# DP GRID 
ROWS,COLS = 7,9
CELL = min((WIDTH-20)//COLS, (HEIGHT-BAR_HEIGHT-160)//ROWS)
OX = (WIDTH-COLS*CELL) // 2; OY = 110

def draw_grid(screen, dp, obstacles = None, highlight = None, path = None):
    screen.fill((255,255,255))
    for r in range(ROWS):
        for c in range(COLS):
            rx = OX+c*CELL; ry = OY+r*CELL
            rect = pygame.Rect(rx,ry,CELL,CELL)
            if obstacles and obstacles[r][c]: color = (30,30,30)
            elif r == 0 and c == 0: color = (80,200,100)
            elif r == ROWS-1 and c == COLS-1: color = (255,140,40)
            elif path and (r,c) in path: color = (100,180,255)
            elif highlight == (r,c): color = (255,180,180)
            else: color = (200,200,200)
            pygame.draw.rect(screen,color,rect)
            pygame.draw.rect(screen,(0,0,0),rect,1)
            val = dp[r][c] if dp else None
            if val is not None and not (obstacles and obstacles[r][c]):
                tc = (255,255,255) if color in [(30,30,30),(80,200,100),(255,140,40),(100,180,255)] else (0,0,0)
                t = FONT.render(str(val),True,tc)
                screen.blit(t,t.get_rect(center=rect.center))

def count_paths_animated(screen,clock,dp,obstacles):
    for r in range(ROWS):
        for c in range(COLS):
            if obstacles[r][c]: dp[r][c] = 0; continue
            dp[r][c] = 1 if r == 0 and c == 0 else (dp[r-1][c] if r>0 else 0) + (dp[r][c-1] if c>0 else 0)
            draw_grid(screen,dp,obstacles,(r,c))
            draw_toolbar(screen,algorithm = "DP - Unique Paths", status = f"Filling ({r},{c}) = {dp[r][c]}", controls = "ESC = Cancel")
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT: pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return False
            pygame.time.wait(80)
    return True

def reconstruct_path(dp,obstacles):
    path = set(); r,c = ROWS-1, COLS-1
    if dp[r][c] == 0: return path
    path.add((r,c))
    while r > 0 or c > 0:
        if r == 0: c -= 1
        elif c == 0: r -= 1
        elif dp[r-1][c] >= dp[r][c-1]: r -= 1
        else: c -= 1
        path.add((r,c))
    return path

def run_dp_puzzle(screen, clock):
    _fonts()
    dp = [[None]*COLS for _ in range(ROWS)]
    obstacles = [[False]*COLS for _ in range(ROWS)]
    path = set(); status = "Click cells to add obstacles, then click Solve"

    btn_solve = Button(10, 10, 120, 36, "Solve", (40,160,60)) 
    btn_reset = Button(140, 10, 110, 36, "Reset", (80,80,120)) 
    btn_rand = Button(260, 10, 175, 36, "Random Obstacles", (60,80,160)) 
    btn_back = Button(WIDTH-140,10,130,36, "Back", (80,80,100)) 

    def reset():
        nonlocal dp, obstacles, path, status
        dp = [[None]*COLS for _ in range(ROWS)]
        obstacles = [[False]*COLS for _ in range(ROWS)]
        path = set(); status = "Reset - click cells to add obstacles, then Solve"

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return

            if btn_solve.clicked(event):
                dp = [[None]*COLS for _ in range(ROWS)]; path = set()
                ok = count_paths_animated(screen, clock, dp, obstacles)
                if ok:
                    total = dp[ROWS-1][COLS-1]; path = reconstruct_path(dp,obstacles)
                    status = f"Total unique paths = {total}"+(" (no route!)" if total == 0 else " | Blue cells show one valid path")
            if btn_reset.clicked(event): reset()
            if btn_rand.clicked(event):
                reset()
                for r2 in range(ROWS):
                    for c2 in range(COLS):
                        if random.random()<0.22 and not(r2 == 0 and c2 == 0) and not(r2 == ROWS-1 and c2 == COLS-1):
                            obstacles[r2][c2] = True
                status = "Random obstacles placed - click Solve"
            if btn_back.clicked(event): return

            # Toggle obstacle by clicking on grid cell
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx,my = event.pos
                gc = (mx-OX)//CELL; gr = (my-OY)//CELL
                if 0 <= gr < ROWS and 0 <= gc < COLS:
                    if not(gr == 0 and gc == 0) and not(gr == ROWS-1 and gc == COLS-1):
                        obstacles[gr][gc] = not obstacles[gr][gc]
                        dp = [[None]*COLS for _ in range(ROWS)]; path = set()
                        status = "Obstacle changed - click Solve"

        draw_grid(screen, dp, obstacles, None, path)
        for b in (btn_solve, btn_reset, btn_rand, btn_back): b.draw(screen)
        screen.blit(SMALL.render(status, True, (0,80,0)), (10,72))
        draw_toolbar(screen, algorithm = "DP - Unique Paths with Obstacles",
                     status = "Green = Start | Orange = End | Black = Wall | Blue = One Path | Numbers = All Paths",
                     controls = "Click Cell = Toggle Wall  |  ESC = Back")
        pygame.display.flip(); clock.tick(30)


# PATH FINDING 
P_COLS, P_ROWS = 50, 33
CW = (WIDTH-10) // P_COLS; CH = (HEIGHT-BAR_HEIGHT-60) // P_ROWS

class Spot:
    def __init__(self,i,j):
        self.x = i; self.y = j; self.f = self.g = self.h = 0
        self.neighbors = []; self.prev = None; self.wall = False; self.visited = False
    def show(self,win,col):
        if self.wall: col = (0,0,0)
        pygame.draw.rect(win,col,(self.x*CW+5,self.y*CH+50,CW-1,CH-1))
    def add_neighbors(self,grid):
        if self.x<P_COLS-1: self.neighbors.append(grid[self.x+1][self.y]) 
        if self.x>0: self.neighbors.append(grid[self.x-1][self.y]) 
        if self.y<P_ROWS-1: self.neighbors.append(grid[self.x][self.y+1]) 
        if self.y>0: self.neighbors.append(grid[self.x][self.y-1]) 

def heuristics(a,b):
    return math.sqrt((a.x-b.x)**2+abs(a.y-b.y)**2)

def _make_grid():
    g = [[Spot(i,j) for j in range(P_ROWS)] for i in range(P_COLS)]
    for i in range(P_COLS):
        for j in range(P_ROWS): g[i][j].add_neighbors(g)
    return g

def run_pathfinding(screen, clock):
    _fonts()
    grid = _make_grid(); start = grid[0][0]; end = grid[P_COLS-1][P_ROWS-1]
    start.wall = end.wall = False
    openSet = []; closeSet = []; queue = deque()
    path = []; flag = False; noflag = True; startflag = False
    mode = 'A*'; status = "Draw walls (left-click drag), then click Run"

    btn_run = Button(10, 10, 110, 36, "Run", (40,160,60)) 
    btn_toggle = Button(130, 10, 160, 36, f"Mode: {mode}", (60,100,180)) 
    btn_reset = Button(300, 10, 110, 36, "Reset", (80,80,120)) 
    btn_back = Button(WIDTH-140, 10, 130, 36, "Back", (80,80,100))

    def reset():
        nonlocal grid, start, end, openSet, closeSet, queue, path, flag, noflag, startflag, status
        grid = _make_grid(); start = grid[0][0]; end = grid[P_COLS-1][P_ROWS-1]
        start.wall = end.wall = False
        openSet = []; closeSet = []; queue = deque()
        path = []; flag = False; noflag = True; startflag = False
        status = "Draw walls, then click Run"

    def cell_at(pos):
        return (pos[0]-5)//CW, (pos[1]-50)//CH

    while True:
        btn_toggle.label = f"Mode: {mode}"

        for event in pygame.event.get():
            if event.type==pygame.QUIT: pygame.quit(); sys.exit()
            if event.type==pygame.KEYDOWN and event.key==pygame.K_ESCAPE: return

            if btn_run.clicked(event) and not startflag:
                startflag = True; status = f"Running {mode}…"
                if mode == 'A*': openSet = [start]
                else:
                    for col in grid:
                        for c in col: c.visited = False; c.prev = None
                    queue = deque([start]); start.visited = True

            if btn_toggle.clicked(event):
                mode = 'Dijkstra' if mode == 'A*' else 'A*'; reset()
                status = f"Switched to {mode} - draw walls then click Run"

            if btn_reset.clicked(event): reset()
            if btn_back.clicked(event): return

            # Wall drawing
            if event.type == pygame.MOUSEBUTTONDOWN and not startflag:
                gx,gy = cell_at(event.pos)
                if 0 <= gx < P_COLS and 0 <= gy < P_ROWS:
                    if event.button == 1 and grid[gx][gy] not in (start,end): grid[gx][gy].wall = True
                    elif event.button == 3: grid[gx][gy].wall = False
            if event.type == pygame.MOUSEMOTION and not startflag:
                if event.buttons[0]:
                    gx,gy = cell_at(event.pos)
                    if 0 <= gx < P_COLS and 0 <= gy < P_ROWS and grid[gx][gy] not in (start,end): grid[gx][gy].wall = True
                elif event.buttons[2]:
                    gx,gy = cell_at(event.pos)
                    if 0 <= gx < P_COLS and 0 <= gy < P_ROWS: grid[gx][gy].wall = False

        # A* step
        if startflag and mode == 'A*':
            for _ in range(6):
                if openSet:
                    winner = 0
                    for i in range(len(openSet)):
                        if openSet[i].f<openSet[winner].f: winner = i
                    current = openSet[winner]
                    if current == end:
                        t = current
                        while t.prev: path.append(t.prev); t = t.prev
                        if not flag: flag = True; status = f"A* found path! Length = {len(path)}"
                        break
                    if not flag:
                        openSet.remove(current); closeSet.append(current)
                        for nb in current.neighbors:
                            if nb in closeSet or nb.wall: continue
                            tempG = current.g+1; newPath = False
                            if nb in openSet:
                                if tempG < nb.g: nb.g = tempG; newPath = True
                            else: nb.g = tempG; newPath = True; openSet.append(nb)
                            if newPath: nb.h = heuristics(nb,end); nb.f = nb.g+nb.h; nb.prev = current
                else:
                    if noflag: status = "No solution found!"; noflag = False; break

        # Dijkstra step
        if startflag and mode == 'Dijkstra':
            for _ in range(6):
                if queue:
                    current = queue.popleft()
                    if current == end:
                        t = current
                        while t.prev: path.append(t.prev); t = t.prev
                        if not flag: flag = True; status = f"Dijkstra found path! Length = {len(path)}"
                        break
                    if not flag:
                        for i in current.neighbors:
                            if not i.visited and not i.wall: i.visited=True; i.prev = current; queue.append(i)
                else:
                    if noflag and not flag: status = "No solution found!"; noflag = False; break

        screen.fill((20,20,35))
        path_set = {id(c) for c in path}
        open_ids = {id(c) for c in openSet} if mode == 'A*' else {id(c) for c in queue}
        closed_ids = {id(c) for c in closeSet} if mode == 'A*' else set()
        vis_ids = set() if mode == 'A*' else {id(c) for col in grid for c in col if c.visited}
        for col in grid:
            for cell in col:
                if cell is start: cc = (80,200,100) 
                elif cell is end: cc = (255,140,40) 
                elif cell.wall: cc = (10,10,20) 
                elif id(cell) in path_set: cc = (100,180,255) 
                elif id(cell) in closed_ids: cc = (120,40,40) 
                elif id(cell) in vis_ids: cc = (40,120,80) 
                elif id(cell) in open_ids: cc = (40,120,40) 
                else: cc = (40,45,65) 
                cell.show(screen,cc)

        for b in (btn_run, btn_toggle, btn_reset, btn_back): b.draw(screen)
        draw_toolbar(screen, algorithm = f"Pathfinding - {mode}",
                     status = status, 
                     controls = "L-drag = Draw wall  R-drag = Erase  |  ESC = Back")
        pygame.display.flip(); clock.tick(60)


# SUB MENU 
def run_puzzles(screen, clock):
    _fonts()
    font = pygame.font.SysFont(None, 34)
    W = screen.get_width()
    items = [
        ("DP Grid - Unique Paths", run_dp_puzzle),
        ("Pathfinding - A* / Dijkstra", run_pathfinding),
        ("Back to Main Menu", None),
    ]
    buttons = [Button(W//2-150, 115+i*70, 300, 46, lbl, (80,100,160)) for i,(lbl,_) in enumerate(items)]
    buttons[-1].color = (80, 80, 100)

    while True:
        screen.fill((200, 200, 250))
        title = font.render("Puzzle Challenges - Phase 3", True, (0, 0, 100))
        screen.blit(title, (W//2 - title.get_width()//2, 35))
        for b in buttons:
            b.draw(screen)
        draw_toolbar(screen, algorithm = "Phase 3 - Puzzles", status = "",
                     controls = "Click a puzzle to launch  |  ESC = Back")
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: return
            for b, (_, fn) in zip(buttons, items):
                if b.clicked(event):
                    if fn is None: return
                    fn(screen, clock)
        clock.tick(30)
